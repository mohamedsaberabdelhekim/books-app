module.exports = {
  //local MongoDB deployment ->
  "URI": "mongodb://localhost/books229"
};
